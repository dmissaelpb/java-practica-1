package com.act1hi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Act1HiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Act1HiApplication.class, args);
	}

}
