package com.act1hi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Act1HiApplicationTests {

	@Test
	void contextLoads() {
	}

}
